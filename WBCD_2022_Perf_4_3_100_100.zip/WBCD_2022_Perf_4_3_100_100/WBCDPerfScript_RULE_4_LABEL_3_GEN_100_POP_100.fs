/* FUGE-LC Reference script 

	Author: JPA
	Date  : 01-2010
	Modifications: Author and archeologist : 04.2022 - Thibault Schowing

 	Note: the name of the functions cannot be changed 							
*/

// Experiment name appearing in the logs
experimentName = "WBCD_2022_Perf_4_3_100_100";

// Directory where logs, fuzzy systems and temporary files are saved
savePath = "C:/Users/TWG/Desktop/WBCD_2022_Perf_4_3_100_100";

//------------------------------
// Fuzzy system parameters 
//------------------------------
/*	Parameters explanation

- *fixedVars*: 	Fixed Number of variables per rules (?)
- *nbRules*:  	Maximum number of rules for the fuzzy system
- *nbMaxVarPerRule*:		Maximal number of linguistic variable per rule
- *nbOutVars*:		Number of output variables 
- *nbInSets*:		**?** Number of sets for the input variable: 2
- *nbOutSets*:		**?** Number of sets for the output variable
- *nVarsCodeSize*:		Number of bits needed to code the number of input variable (if 7 input variables-> 3 bits)
- *outVarsCodeSize*:	Number of bits needed to code the number of output variable (Here it's a binary problem with one variable -> 1 bit)
- *inSetsCodeSize*:		**?** Number of bits used to code an input set in the genome
- *outSetsCodeSize*: 	**?** Number of bits used to code an output set in the genome
- *inSetsPosCodeSize*: 	**?** Number of bits used to code the position parameter for the input sets
- *utSetPosCodeSize*:	**?** Number of bits used to code the position parameter for the output sets

*/

fixedVars = false;
nbRules = 4;
nbMaxVarPerRule = 3;
nbOutVars = 1;
nbInSets = 3;
nbOutSets = 2;
inVarsCodeSize = 5;
outVarsCodeSize = 1;
inSetsCodeSize = 2;
outSetsCodeSize = 1;
inSetsPosCodeSize = 4;
outSetPosCodeSize = 1;

// Co-evolution parameters
// Population 1: Membership Functions (Variables)
maxGenPop1 = 100;
maxFitPop1 = 0.99;
elitePop1 = 5;
popSizePop1 = 100;
cxProbPop1 = 0.9;
mutFlipIndPop1 = 0.2;
mutFlipBitPop1 = 0.01;

// Population 2: Rules
elitePop2 = 5;
popSizePop2 = 100;
cxProbPop2 = 0.6;
mutFlipIndPop2 = 0.4;
mutFlipBitPop2 = 0.01;

// Fitness parameters
sensitivityW = 1.0;
specificityW = 0.8;
accuracyW = 0.0;
ppvW = 0.0;
rmseW = 0.1;
rrseW = 0.0;
raeW = 0.0;
mxeW = 0.0;
distanceThresholdW = 0.0;
distanceMinThresholdW = 0.0;
dontCareW = 0.1;
overLearnW = 0.0;
threshold = 0.5;
threshActivated = true;

function doSetParams()
{
	this.setParams(experimentName, savePath, fixedVars, nbRules, nbMaxVarPerRule, nbOutVars, nbInSets, nbOutSets, inVarsCodeSize, outVarsCodeSize, 
				 inSetsCodeSize, outSetsCodeSize, inSetsPosCodeSize, outSetPosCodeSize, maxGenPop1, maxFitPop1, elitePop1, popSizePop1, 
				 cxProbPop1, mutFlipIndPop1, mutFlipBitPop1, maxGenPop1, maxFitPop1, elitePop2, popSizePop2, cxProbPop2, mutFlipIndPop2, 
				 mutFlipBitPop2, sensitivityW, specificityW, accuracyW, ppvW, rmseW, rrseW, raeW, mxeW, distanceThresholdW,
			         distanceMinThresholdW, dontCareW, overLearnW, threshold, threshActivated);
}

// Run function called by FUGE-LC. This function MUST also be present
function doRun() 
{
	var nRuleVals = [4];
	var popVals = [100];

	// Multiple coevolution runs with different parameters
	for (var i = 0; i < nRuleVals.length; i++) {
		for (var j = 0; j < popVals.length; j++) {
			for (var n = 0; n < 1; n++) {
				nbRules = nRuleVals[i];
				popSizePop1 = popVals[j];
				popSizePop2 = popVals[j];			
				this.runEvo();
			}
		}
	}
}
// EOF
